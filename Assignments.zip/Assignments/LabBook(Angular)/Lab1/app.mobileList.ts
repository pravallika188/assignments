import { Mobile } from './app.mobile';
export const mobileList:Mobile[] = [new Mobile(10001,"HTC1M9",22000),
				    new Mobile(10002,"MINOTE7",8999)];