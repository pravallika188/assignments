package com.cg.bgv.dto;

public class Documents 
{
int DocId;
String DocType;
date issuedDate;
String issuedAuthority;
public Documents() {
	super();
}
public Documents(int docId, String docType, date issuedDate, String issuedAuthority) {
	super();
	DocId = docId;
	DocType = docType;
	this.issuedDate = issuedDate;
	this.issuedAuthority = issuedAuthority;
}
public int getDocId() {
	return DocId;
}
public void setDocId(int docId) {
	DocId = docId;
}
public String getDocType() {
	return DocType;
}
public void setDocType(String docType) {
	DocType = docType;
}
public date getIssuedDate() {
	return issuedDate;
}
public void setIssuedDate(date issuedDate) {
	this.issuedDate = issuedDate;
}
public String getIssuedAuthority() {
	return issuedAuthority;
}
public void setIssuedAuthority(String issuedAuthority) {
	this.issuedAuthority = issuedAuthority;
}


}
