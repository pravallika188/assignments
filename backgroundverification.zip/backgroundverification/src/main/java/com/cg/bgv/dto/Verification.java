package com.cg.bgv.dto;

public class Verification
{
  Employee empid;
  String status;
public Verification() {
	super();
}
public Verification(Employee empid, String status) {
	super();
	this.empid = empid;
	this.status = status;
}
public Employee getEmpid() {
	return empid;
}
public void setEmpid(Employee empid) {
	this.empid = empid;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
  
  
}
